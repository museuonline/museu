DEBUG = True
ADMINS = frozenset([
    'neldo@digio.com'
])