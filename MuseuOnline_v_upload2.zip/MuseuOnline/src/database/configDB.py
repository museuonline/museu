config = {
    'user': 'root',
    'password': 'digio+*12',
    'host': '127.0.0.1',
    'database': 'museuonlinebd',
    'autocommit': True,
    'port': 3306
}