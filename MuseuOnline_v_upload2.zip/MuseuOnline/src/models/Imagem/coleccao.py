coleccao = "especieImagem"
path_image = "/home/digio/Desktop/projectos/MuseuOnline/src/static/img"