coleccao = "utilizador"
pedido = "cadastroPedido"